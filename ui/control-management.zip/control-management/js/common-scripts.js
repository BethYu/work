/*-------*/

var Script = function () {

    $(function() {

    });

  $('').click(function () {

  });
}();
